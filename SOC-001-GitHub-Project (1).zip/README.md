# Windows Security Log Investigation — SOC-001

## Overview
Investigated Windows authentication events during an **authorized local login-failure simulation** using Windows Event Viewer. This is a training exercise, **not a confirmed cyberattack**.

## Tools and skills
- Windows 11 Event Viewer, Windows Security log
- Event filtering, authentication analysis, timestamp correlation, incident documentation

## Investigation procedure
1. Opened Event Viewer → Windows Logs → Security.
2. Filtered Event ID `4625` to identify failed logons.
3. Performed two intentional failed sign-ins on my own workstation.
4. Located two failed logons and reviewed the event details.
5. Filtered `4624,4625` and inspected nearby successful logons.
6. Compared timestamps, logon types, and available source details.

## Timeline (November 19, 2026)
| Time | Event ID | Outcome | Logon type |
|---|---|---|---|
| 08:49:09 | 4625 | Failed | 2 — Interactive |
| 08:49:14 | 4625 | Failed | 2 — Interactive |
| 08:49:22 | 4624 | Successful | 11 — Cached interactive |

## Findings
- The two failures occurred five seconds apart.
- A successful cached-interactive logon appeared eight seconds after the second failure.
- A loopback source address (`127.0.0.1`) was observed.
- Failure status `0xC000006D` and substatus `0xC0000380` were recorded.
- The failed events did not identify a target account, so direct correlation with the successful event **was not proven**.
- Because the test was deliberately performed by the workstation owner, the observed pattern is consistent with authorized testing.

## Conclusion
**Classification: Authorized security simulation.** No compromise was established. Timestamp proximity is not sufficient to prove that separate authentication events belong to the same session.

## Evidence
![Two failed logons](screenshots/01-failed-logins.png)
![Failure codes](screenshots/02-failure-details.png)
![Failure source](screenshots/03-failure-source.png)
![Nearby successful events](screenshots/04-success-logon.png)
![Loopback address](screenshots/05-success-source.png)

See [incident-report.md](incident-report.md) for the formal report.

> Privacy: evidence images were cropped to omit account names, email addresses and device identifiers. Original unredacted screenshots are not published.
